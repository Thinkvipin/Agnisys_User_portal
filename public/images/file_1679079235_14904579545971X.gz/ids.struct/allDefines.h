
#define hwint32 int
#define hwint8 int
#define hwint16 int
#define hwint int
typedef unsigned int    unsignInt32;
typedef signed int    	signInt32;
typedef unsigned char	unsignInt8;
typedef signed char	    signInt8;
typedef unsigned char	byte;
typedef unsigned short  unsignInt16;
typedef signed short    signInt16;

typedef uint8_t unsignWord8;
typedef uint16_t unsignWord16;
typedef uint32_t unsignWord32;
typedef uint64_t unsignWord64;
#define   AGNISYS_REG_RESET_CHECK_ON

//#define   AGNISYS_REG_WRITE_RANDOM_CHECK_ON

#define   AGNISYS_REG_WRITE_ONES_CHECK_ON

#define   AGNISYS_REG_WRITE_ZERO_CHECK_ON

#define   AGNISYS_REG_WRITE_WALKING_ONES_CHECK_ON

#define   AGNISYS_REG_WRITE_WALKING_ONES_A_CHECK_ON
