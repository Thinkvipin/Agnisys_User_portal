
#ifndef AGNISYS_API_FIRMWARE_H__
#define AGNISYS_API_FIRMWARE_H__

int write32_mem(volatile uint32_t* addr, uint32_t val)
{
	*addr = (uint32_t)(val);
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

	printf("Write Addr ", (uintptr_t) addr);
	printf("with Data ", (uint32_t) val);
		#endif	
		return 0;
}
int write64_mem(volatile uint64_t* addr, uint64_t val)
{
	*addr = (uint64_t)(val);
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

	printf("Write Addr ", (uintptr_t) addr);
	printf("with Data ", (uint64_t) val);
		#endif	
		return 0;
}

int read32_mem_chk(volatile uint32_t* addr, uint32_t exp)
{
	uint32_t rddata = *addr;

	if (rddata != exp){
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		#endif	
		return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}


int read64_mem_chk(volatile uint64_t* addr, uint64_t exp)
{
	uint64_t rddata = *addr;

	if (rddata != exp){
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		#endif	
		return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}


uint32_t read32_reg(volatile uint32_t* addr)
{
    uint32_t rddata = *addr;
    return rddata;
}
        


int write16_mem(volatile uint32_t* addr, uint16_t val)
{
	*addr = (uint16_t)(val);
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

	printf("Write Addr ", (uintptr_t) addr);
	printf("with Data ", (uint16_t) val);
	#endif	
	return 0;
}

int read16_mem_chk(volatile uint32_t* addr, uint16_t exp)
{
	uint16_t rddata = *addr;

	if (rddata != exp){
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		#endif	
	return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}


int write8_mem(volatile uint32_t* addr, uint8_t val)
{
	*addr = (uint8_t)(val);
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

	printf("Write Addr ", (uintptr_t) addr);
	printf("with Data ", (uint8_t) val);
		#endif	
	return 0;
}

int read8_mem_chk(volatile uint32_t* addr, uint8_t exp)
{
	uint8_t rddata = *addr;

	if (rddata != exp){
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		#endif	
	return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}

int write_mem_offset(volatile uint32_t* addr, uint32_t idx, uint32_t val)
{
	addr += idx;
	*addr = (uint32_t)(val);
	return 0;
}

int write_mem_offset_16(volatile uint32_t* addr, uint32_t idx, uint16_t val)
{
	addr += idx;
	*addr = (uint16_t)(val);
	return 0;
}

int write_mem_offset_8(volatile uint32_t* addr, uint32_t idx, uint8_t val)
{
	addr += idx;
	*addr = (uint8_t)(val);
	return 0;
}

int write_mem_offset_64(volatile uint32_t* addr, uint32_t idx, uint64_t val)
{
	addr += idx;
	*addr = (uint64_t)(val);
	return 0;
}

int read_mem_offset(volatile uint32_t* addr, uint32_t idx, uint32_t exp)
{

	addr += idx;
	uint32_t rddata = *addr;

	if (rddata != exp) {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		printf("Index = ", idx);
		#endif	
	return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}

int read_mem_offset_16(volatile uint32_t* addr, uint32_t idx, uint16_t exp)
{

	addr += idx;
	uint16_t rddata = *addr;

	if (rddata != exp) {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		printf("Index = ", idx);
		#endif	
	return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}

int read_mem_offset_8(volatile uint32_t* addr, uint32_t idx, uint8_t exp)
{

	addr += idx;
	uint8_t rddata = *addr;

	if (rddata != exp) {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		printf("Index = ", idx);
		#endif	
	return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}

int read_mem_offset_64(volatile uint32_t* addr, uint32_t idx, uint64_t exp)
{

	addr += idx;
	uint64_t rddata = *addr;

	if (rddata != exp) {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		printf("Mismatch reading ", (uintptr_t)addr);
		printf("Index = ", idx);
		#endif	
	return 1;
} else {
    #ifdef   AGNISYS_REG_CHECK_MSG_ON

		PrintInfo(3,"Addr : 0x%x, Read data : 0x%x, Exp Data : 0x%x", addr, rddata, exp); 	
		#endif	
		return 0 ; 
	}
}
// Default FPGA's function, can be modified depending on the FPGA requirement

#define REG32_WRITE(ADDR,WDATA)	write32_mem((uint32_t*)(intptr_t)(ADDR), WDATA)

#define REG64_WRITE(ADDR,WDATA)	write64_mem((uint64_t*)(intptr_t)(ADDR), WDATA)

#define READ32_CHK(addr,val)	read32_mem_chk((uint32_t*) (addr), val)

#define READ64_CHK(addr,val)	read64_mem_chk((uint64_t*) (addr), val)

#define REG32_READ(addr)	read32_reg((uint32_t*) (addr))

#define REG16_WRITE(ADDR,WDATA)	write16_mem((uint32_t*)(intptr_t)(ADDR), WDATA)

#define READ16_CHK(addr,val)	read16_mem_chk((uint32_t*) (addr), val)

#define REG8_WRITE(ADDR,WDATA)	write8_mem((uint32_t*)(intptr_t)(ADDR), WDATA)

#define READ8_CHK(addr,val)	read8_mem_chk((uint32_t*) (addr), val)

#define READ32_CHK_IDX(addr,idx,val)	read_mem_offset((uint32_t*) (addr), idx, val)

#define READ16_CHK_IDX(addr,idx,val)	read_mem_offset_16((uint32_t*) (addr), idx, val)

#define READ8_CHK_IDX(addr,idx,val)	read_mem_offset_8((uint32_t*) (addr), idx, val)

#define READ64_CHK_IDX(addr,idx,val)	read_mem_offset_64((uint32_t*) (addr), idx, val)

#define WRITE32_IDX(addr,idx,val)	write_mem_offset((uint32_t*) (addr), idx, val)

#define WRITE16_IDX(addr,idx,val)	write_mem_offset_16((uint32_t*) (addr), idx, val)

#define WRITE8_IDX(addr,idx,val)	write_mem_offset_8((uint32_t*) (addr), idx, val)

#define WRITE64_IDX(addr,idx,val) 	write_mem_offset_64((uint32_t*) (addr), idx, val)
#endif
