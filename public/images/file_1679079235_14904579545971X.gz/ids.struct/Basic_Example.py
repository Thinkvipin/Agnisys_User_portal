 # -*- coding: iso-8859-15 -*- 
top_block = {
       
        
'Chip' :
{
        'type' : 'block',
        
        'name' : "Chip",
        'widget' : "apb::abp_widget",
        'sv_interface' : "struct",
        'refNameID' : "Chip",
        'global' : "true",
        'display_name' : "Chip Address Map",
        'offset' : "0",
        'address' : "0x0",
        'endaddress' : "0xB",
        'size' : "12",
        'config' :
        {
                'type' : 'config',
                
                'regwidth' : "32",
                'addressunit' : "8",
                'buswidth' : "32",
                'busdomains' :
                {
                        
                        'default_map' :
                        {
                                'type' : 'busdomain',
                                
                                'name' : "default_map",
                                'bus' : "APB",
                                'addressUnit' : "8",
                                'offset' : "0",
                                'address' : "0x0",
                                'endaddress' : "0xB",
                                'size' : "12",
                                
                        }
                },
                
                'variants' :
                {
                        
                        'none' :
                        {
                                'type' : 'variant',
                                
                                'name' : "none",
                                'isselected' : "true",
                                
                                'doc' : "'none' variant states including all templates which are not assigned any    variant property."
                        }
                }
                
        },
        'Simple_block' :
        {
                'type' : 'section',
                
                'name' : "Simple_block",
                'offset' : "0",
                'refNameID' : "Simple_block",
                'display_name' : "Simple_block Address Map",
                'keypathdown' : "Simple_block.Reg_1.Reg_2.Reg_3,Reg_1,Reg_2,Reg_3",
                'max_reg_size' : "32",
                'address' : "0x0",
                'endaddress' : "0xB",
                'size' : "12",
                'config' :
                {
                        'type' : 'config',
                        
                        'busdomains' :
                        {
                                
                                'default_map' :
                                {
                                        'type' : 'busdomain',
                                        
                                        'name' : "default_map",
                                        'bus' : "APB",
                                        'addressUnit' : "8",
                                        'offset' : "0",
                                        'address' : "0x0",
                                        'endaddress' : "0xB",
                                        'size' : "12",
                                        
                                }
                        },
                        
                },
                'Reg_1' :
                {
                        'type' : 'reg',
                        
                        'name' : "Reg_1",
                        'offset' : "0",
                        'refNameID' : "Reg_1",
                        'address' : "0x0",
                        'endaddress' : "0x3",
                        'size' : "4",
                        'default' : "0x00000000",
                        'sw' : "rw",
                        'hw' : "rw",
                        'doc' : "This is a 32-bit register",
                        'config' :
                        {
                                'type' : 'config',
                                
                                'regwidth' : "32",
                                'busdomains' :
                                {
                                        
                                        'default_map' :
                                        {
                                                'type' : 'busdomain',
                                                
                                                'name' : "default_map",
                                                'bus' : "APB",
                                                'addressUnit' : "8",
                                                'offset' : "0",
                                                'address' : "0x0",
                                                'endaddress' : "0x3",
                                                'size' : "4",
                                                
                                        }
                                },
                                
                        },
                        'Fld1' :
                        {
                                'type' : 'field',
                                
                                'name' : "Fld1",
                                'offset' : "31:0",
                                
                                'sw' : "rw",
                                
                                'hw' : "rw",
                                'default' : "0x0",
                                'doc' : "This is a register field."
                        }
                },
                'Reg_2' :
                {
                        'type' : 'reg',
                        
                        'name' : "Reg_2",
                        'offset' : "4",
                        'refNameID' : "Reg_2",
                        'address' : "0x4",
                        'endaddress' : "0x7",
                        'size' : "4",
                        'default' : "0x00000000",
                        'sw' : "rw",
                        'hw' : "rw",
                        'doc' : "This is a 32-bit fixed width register",
                        'config' :
                        {
                                'type' : 'config',
                                
                                'regwidth' : "32",
                                'busdomains' :
                                {
                                        
                                        'default_map' :
                                        {
                                                'type' : 'busdomain',
                                                
                                                'name' : "default_map",
                                                'bus' : "APB",
                                                'addressUnit' : "8",
                                                'offset' : "4",
                                                'address' : "0x4",
                                                'endaddress' : "0x7",
                                                'size' : "4",
                                                
                                        }
                                },
                                
                        },
                        'Fld1' :
                        {
                                'type' : 'field',
                                
                                'name' : "Fld1",
                                'offset' : "31:0",
                                
                                'sw' : "rw",
                                
                                'hw' : "rw",
                                'default' : "0x0"
                        }
                },
                'Reg_3' :
                {
                        'type' : 'reg',
                        
                        'name' : "Reg_3",
                        'offset' : "8",
                        'refNameID' : "Reg_3",
                        'address' : "0x8",
                        'endaddress' : "0xB",
                        'size' : "4",
                        'default' : "0x00000000",
                        'sw' : "rw",
                        'hw' : "rw",
                        'doc' : "Likewise you can add any number of blocks with registers according to design requirement, where chip is the top level component.",
                        'config' :
                        {
                                'type' : 'config',
                                
                                'regwidth' : "32",
                                'busdomains' :
                                {
                                        
                                        'default_map' :
                                        {
                                                'type' : 'busdomain',
                                                
                                                'name' : "default_map",
                                                'bus' : "APB",
                                                'addressUnit' : "8",
                                                'offset' : "8",
                                                'address' : "0x8",
                                                'endaddress' : "0xB",
                                                'size' : "4",
                                                
                                        }
                                },
                                
                        },
                        'Fld1' :
                        {
                                'type' : 'field',
                                
                                'name' : "Fld1",
                                'offset' : "31:0",
                                
                                'sw' : "rw",
                                
                                'hw' : "rw",
                                'default' : "0x0"
                        }
                }
        }
}

};
        

    