idsbatch blk_regs.rdl -inp rdl -out "verilog2001 html pdf" -default_reset async -rtl_wire -lowpower -bus axi4lite -reg_width 32 -bus_width 32 -company "ABC" -copyright "Copyright 2020" -log agni_blk.log -dir blk_ids  -preserve

