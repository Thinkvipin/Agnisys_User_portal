# /tools/agnisys/idsbatch/idsbatch
#   -incdir /home/klee/canis/sysRDL
#   -out 'verilog uvm header htmlalt2'
#   -velocity '/home/klee/canis/sysRDL/templates/reg_access.h.vm /home/klee/canis/sysRDL/templates/reg_info.c.vm'
#   -big_endian false
#   -little_endian true
#   -bus axi
#   -preserve
#   -if
#   -dir '/home/klee/canis/sysRDL/build/canis.csr'
#   -dir_out_specific 'html:html.agnisys,verilog:verilog.agnisys,uvm:uvm.agnisys,header:header.agnisys,htmlalt2:htmlalt2.agnisys'
#   /home/klee/canis/sysRDL/rdl/canis.csr.rdl

# -dir_out_specific "verilog:verilog,uvm:uvm,header:header"
idsbatch canis.csr.rdl -out "verilog uvm header" -bus axi -preserve -dir output -if -big_endian false -little_endian true -dir_out_specific 'html:html.agnisys,verilog:verilog.agnisys,uvm:uvm.agnisys,header:header.agnisys,htmlalt2:htmlalt2.agnisys' -velocity '/home/klee/canis/sysRDL/templates/reg_access.h.vm /home/klee/canis/sysRDL/templates/reg_info.c.vm'
